﻿using Bogus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QTCityCongestionCharge.ConApp
{
    partial class Program
    {
        static partial void AfterRun()
        {
        }
    }
}
