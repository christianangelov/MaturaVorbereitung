﻿//@CodeCopy
//MdStart
global using CommonBase;
global using CommonBase.Extensions;
global using System.ComponentModel.DataAnnotations;
global using System.ComponentModel.DataAnnotations.Schema;
global using Microsoft.EntityFrameworkCore;
//MdEnd
