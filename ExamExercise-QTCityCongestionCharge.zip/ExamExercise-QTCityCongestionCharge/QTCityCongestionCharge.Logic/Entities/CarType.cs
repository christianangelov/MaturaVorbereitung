﻿namespace QTCityCongestionCharge.Logic.Entities
{
    public enum CarType
    {
        PassengerCar = 1,
        Lorry = 20,
        Van = 30,
        Motorcycle = 40,
    }
}
