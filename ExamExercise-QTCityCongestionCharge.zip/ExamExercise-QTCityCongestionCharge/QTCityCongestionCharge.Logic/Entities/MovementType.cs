﻿namespace QTCityCongestionCharge.Logic.Entities
{
    public enum MovementType
    {
        Entering,
        Leaving,
        DrivingInside,
    }
}
