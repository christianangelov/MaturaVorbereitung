﻿//@CodeCopy
//MdStart

namespace QTCityCongestionCharge.Logic
{
    public interface IIdentifyable
    {
        int Id { get; }
    }
}
//MdEnd
