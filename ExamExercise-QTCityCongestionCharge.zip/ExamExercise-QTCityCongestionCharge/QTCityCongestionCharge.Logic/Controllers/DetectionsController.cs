﻿namespace QTCityCongestionCharge.Logic.Controllers
{
    public class DetectionsController : GenericController<Entities.Detection>
    {
        public DetectionsController()
        {
        }

        public DetectionsController(ControllerObject other) : base(other)
        {
        }
    }
}
