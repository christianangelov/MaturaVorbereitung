﻿namespace QTCityCongestionCharge.Logic.Controllers
{
    public class OwnersController : GenericController<Entities.Owner>
    {
        public OwnersController()
        {
        }

        public OwnersController(ControllerObject other) : base(other)
        {
        }
    }
}
