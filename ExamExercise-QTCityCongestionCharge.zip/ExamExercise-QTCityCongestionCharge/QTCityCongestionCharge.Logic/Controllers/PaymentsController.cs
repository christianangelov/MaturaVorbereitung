﻿namespace QTCityCongestionCharge.Logic.Controllers
{
    public class PaymentsController : GenericController<Entities.Payment>
    {
        public PaymentsController()
        {
        }

        public PaymentsController(ControllerObject other) : base(other)
        {
        }
    }
}
