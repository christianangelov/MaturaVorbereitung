﻿namespace QTCityCongestionCharge.Logic.Modules.Fee
{
    public enum ChargeType
    {
        FossileFules,
        ElectricVehicles,
        HybridAndElectricVehicles,
        Lorry = 20,
        Van = 30,
        Motorcycle = 40,
    }
}
