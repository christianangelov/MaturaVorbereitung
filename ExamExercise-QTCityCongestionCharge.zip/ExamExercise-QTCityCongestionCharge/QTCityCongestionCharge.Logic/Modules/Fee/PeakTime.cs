﻿
namespace QTCityCongestionCharge.Logic.Modules.Fee
{
    public class PeakTime
    {
        public DayOfWeek DayOfWeek { get; set; }
        public int From { get; set; }
        public int To { get; set; }
    }
}
