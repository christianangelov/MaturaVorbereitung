﻿namespace QTCityCongestionCharge.Logic.Modules.Fee
{
    public class Charge
    {
        public double Driving { get; set; }
        public double Parking { get; set; }
        public double RushHour { get; set; }
        public double MaxFee { get; set; }
    }
}
