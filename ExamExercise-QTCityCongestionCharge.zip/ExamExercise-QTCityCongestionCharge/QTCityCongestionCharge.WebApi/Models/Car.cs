﻿
namespace QTCityCongestionCharge.WebApi.Models
{
    public class Car : BaseCar
    {
        public int Id { get; set; }
    }
}
